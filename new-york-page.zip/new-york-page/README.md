# New York page

A Pen created on CodePen.io. Original URL: [https://codepen.io/Yana-DEBNOL/pen/ByBqRMO](https://codepen.io/Yana-DEBNOL/pen/ByBqRMO).

