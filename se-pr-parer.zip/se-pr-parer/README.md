# Se préparer

A Pen created on CodePen.io. Original URL: [https://codepen.io/Yana-DEBNOL/pen/JoPmJXJ](https://codepen.io/Yana-DEBNOL/pen/JoPmJXJ).

